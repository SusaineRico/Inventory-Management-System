
SELECT 
    DATE_FORMAT(o.order_date, '%Y-%m') AS Month, 
    SUM(oi.quantity * oi.price) AS TotalSales
FROM Orders o
JOIN OrderItems oi ON o.order_id = oi.order_id
WHERE o.status = 'Completed'
GROUP BY DATE_FORMAT(o.order_date, '%Y-%m')
ORDER BY Month;

SELECT 
    p.name AS ProductName, 
    SUM(oi.quantity * oi.price) AS Revenue
FROM OrderItems oi
JOIN Products p ON oi.product_id = p.product_id
GROUP BY p.name
ORDER BY Revenue DESC
LIMIT 5;

SELECT 
    c.name AS CustomerName, 
    COUNT(o.order_id) AS OrderCount
FROM Orders o
JOIN Customers c ON o.customer_id = c.customer_id
GROUP BY c.name
HAVING OrderCount > 1
ORDER BY OrderCount DESC;

SELECT 
    p.name AS ProductName, 
    p.stock_quantity, 
    p.reorder_level
FROM Products p
WHERE p.stock_quantity <= p.reorder_level
ORDER BY p.stock_quantity ASC;

SELECT 
    s.name AS SupplierName, 
    COUNT(p.product_id) AS ProductsSupplied
FROM Suppliers s
JOIN Products p ON s.supplier_id = p.supplier_id
GROUP BY s.name
ORDER BY ProductsSupplied DESC;

SELECT 
    DATE_FORMAT(date_id, '%Y-%m') AS Month, 
    SUM(total_price) AS TotalSales
FROM SalesFact
GROUP BY DATE_FORMAT(date_id, '%Y-%m')
ORDER BY Month;

SELECT 
    dp.name AS ProductName, 
    SUM(sf.total_price) AS Revenue
FROM SalesFact sf
JOIN DimProduct dp ON sf.product_id = dp.product_id
GROUP BY dp.name
ORDER BY Revenue DESC
LIMIT 5;


